import React, { useState, useCallback } from 'react';
import { AppConfig, DatasetEntry, ShareGPTEntry, OpenAIEntry, AppMode } from './types';
import { Sidebar } from './components/Sidebar';
import { DataEntryForm } from './components/Form';
import { PreviewList } from './components/PreviewList';
import { Landing } from './components/Landing';
import { SyntheticBuilder } from './components/SyntheticBuilder';
import { Button } from './components/UI';

const App = () => {
  // --- STATE ---
  const [mode, setMode] = useState<AppMode>('landing');
  
  const [config, setConfig] = useState<AppConfig>({
    format: 'sharegpt',
    useFixedSystemPrompt: true,
    fixedSystemPrompt: '',
    targetCount: 100,
    filename: 'mi-dataset'
  });

  const [dataset, setDataset] = useState<DatasetEntry[]>([]);
  const [fileHandle, setFileHandle] = useState<FileSystemFileHandle | null>(null);
  const [fileStatus, setFileStatus] = useState<string>('Sin archivo seleccionado');

  // --- HANDLERS ---
  const safeFilename = useCallback(() => (
    config.filename.endsWith('.json') ? config.filename : `${config.filename}.json`
  ), [config.filename]);

  const handlePickFile = useCallback(async () => {
    // Verificar soporte de File System Access API
    const isSupported = 'showSaveFilePicker' in window && window.isSecureContext;
    
    if (!isSupported) {
      const reason = !window.isSecureContext 
        ? 'La página debe estar en HTTPS o localhost. Verifica que estés en http://localhost:3000/'
        : 'Tu navegador no soporta File System Access API.';
      setFileStatus(`⚠️ ${reason}`);
      console.error('File System Access no disponible:', {
        hasAPI: 'showSaveFilePicker' in window,
        isSecure: window.isSecureContext,
        protocol: window.location.protocol,
        host: window.location.host
      });
      return;
    }
    
    try {
      let handle: FileSystemFileHandle;
      
      try {
        // Intentar abrir archivo existente
        const [existingHandle] = await window.showOpenFilePicker({
          types: [
            {
              description: 'JSON Dataset',
              accept: { 'application/json': ['.json'] }
            }
          ]
        });
        handle = existingHandle;
      } catch (openError) {
        // Si cancela o falla, intentar crear uno nuevo
        if ((openError as DOMException).name === 'AbortError') {
          return; // Usuario canceló
        }
        
        handle = await window.showSaveFilePicker({
          suggestedName: safeFilename(),
          types: [
            {
              description: 'JSON Dataset',
              accept: { 'application/json': ['.json'] }
            }
          ]
        });
      }

      // Solicitar permiso de escritura
      const permission = await handle.requestPermission({ mode: 'readwrite' });
      if (permission !== 'granted') {
        setFileStatus('❌ Permiso denegado para escribir en el archivo.');
        return;
      }

      // Verificar contenido actual y crear array vacío si no existe
      const file = await handle.getFile();
      const content = await file.text();
      
      if (content.trim() === '') {
        // Archivo vacío, inicializar con array vacío
        const writable = await handle.createWritable();
        await writable.write('[]');
        await writable.close();
      }

      setFileHandle(handle);
      setFileStatus(`✓ Archivo conectado: ${handle.name}`);
    } catch (error) {
      if ((error as DOMException).name !== 'AbortError') {
        console.error('Error al seleccionar archivo:', error);
        setFileStatus(`❌ Error: ${(error as Error).message || 'No se pudo seleccionar el archivo'}`);
      }
    }
  }, [safeFilename]);

  const appendEntryToFile = useCallback(async (entry: DatasetEntry) => {
    if (!fileHandle) {
      setFileStatus('⚠️ Selecciona un archivo primero.');
      return;
    }
    try {
      // Verificar/solicitar permiso
      const permission = await fileHandle.requestPermission({ mode: 'readwrite' });
      console.log('[DEBUG] Permiso:', permission);
      if (permission !== 'granted') {
        setFileStatus('Permiso denegado. Vuelve a elegir el archivo.');
        return;
      }
      
      // Leer contenido actual del archivo
      const file = await fileHandle.getFile();
      const existingContent = await file.text();
      
      // Parsear el array existente
      let dataArray: DatasetEntry[] = [];
      if (existingContent.trim() !== '') {
        try {
          dataArray = JSON.parse(existingContent);
          if (!Array.isArray(dataArray)) {
            console.error('[DEBUG] El archivo no contiene un array válido');
            setFileStatus('Error: El archivo no contiene un array JSON válido.');
            return;
          }
        } catch (parseError) {
          console.error('[DEBUG] Error parseando JSON:', parseError);
          setFileStatus('Error: El archivo JSON está corrupto.');
          return;
        }
      }
      
      // Agregar el nuevo entry al array
      dataArray.push(entry);
      
      // Escribir el array completo con formato bonito (2 espacios de indentación)
      const formattedJson = JSON.stringify(dataArray, null, 2);
      
      console.log('[DEBUG] Total ejemplos:', dataArray.length);
      console.log('[DEBUG] Nuevo entry agregado');
      
      // Reescribir todo el archivo (no append, sino reemplazo completo)
      const writable = await fileHandle.createWritable();
      await writable.write(formattedJson);
      await writable.close();
      
      // Verificar
      const verifyFile = await fileHandle.getFile();
      console.log('[DEBUG] Nuevo tamaño:', verifyFile.size);
      
      setFileStatus(`✓ Guardado (${dataArray.length} ejemplos): ${fileHandle.name}`);
    } catch (error) {
      console.error('[DEBUG] Error completo:', error);
      setFileStatus('Error al guardar. Revisa la consola (F12).');
    }
  }, [fileHandle]);

  const handleAddManualEntry = useCallback((entry: DatasetEntry) => {
    setDataset(prev => [...prev, entry]);
    appendEntryToFile(entry);
  }, [appendEntryToFile]);

  // Handler for Synthetic Builder (can accept batch)
  const handleAddSyntheticEntries = useCallback(async (entries: DatasetEntry[]) => {
    setDataset(prev => [...prev, ...entries]);
    await Promise.all(entries.map(entry => appendEntryToFile(entry)));
  }, [appendEntryToFile]);

  const handleRemoveEntry = useCallback((indexToRemove: number) => {
    setDataset(prev => prev.filter((_, idx) => idx !== indexToRemove));
  }, []);

  const handleDownload = useCallback(() => {
    if (dataset.length === 0) return;
    const jsonl = dataset.map(entry => JSON.stringify(entry)).join('\n');
    const blob = new Blob([jsonl], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeName = config.filename.endsWith('.jsonl') ? config.filename : `${config.filename}.jsonl`;
    link.download = safeName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [dataset, config.filename]);

  // --- RENDER ---

  // 1. Landing Mode
  if (mode === 'landing') {
    return <Landing onSelectMode={setMode} />;
  }

  // 2. Builder Mode (Manual or Synthetic)
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-blue-500/30">
      
      {/* Sidebar */}
      <Sidebar 
        config={config} 
        currentCount={dataset.length}
        setConfig={setConfig} 
        onDownload={handleDownload}
        onPickFile={handlePickFile}
        fileStatus={fileStatus}
      />

      {/* Main Content */}
      <main className="flex-1 md:ml-0 md:pl-0 pt-20 md:pt-0">
        <div className="max-w-4xl mx-auto p-6 md:p-10">
          
          <header className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">
                {mode === 'manual' ? 'Constructor Manual' : 'Generador Sintético'}
              </h2>
              <p className="text-slate-400">
                Formato activo: <span className="font-mono text-blue-400 font-bold uppercase">{config.format}</span>
              </p>
            </div>
            <Button variant="secondary" size="sm" onClick={() => setMode('landing')}>
              ← Cambiar Modo
            </Button>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Form (Swaps based on mode) */}
            <div className="lg:col-span-2">
              {mode === 'manual' ? (
                <DataEntryForm config={config} onAdd={handleAddManualEntry} />
              ) : (
                <SyntheticBuilder 
                  config={config} 
                  onAdd={handleAddSyntheticEntries} 
                  datasetCount={dataset.length}
                />
              )}
            </div>

            {/* Right Column: Preview & History (Shared) */}
            <div className="lg:col-span-1">
              <div className="sticky top-6">
                <PreviewList 
                  dataset={dataset} 
                  onRemove={handleRemoveEntry} 
                  format={config.format}
                />
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default App;