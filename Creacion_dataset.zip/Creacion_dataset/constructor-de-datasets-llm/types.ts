export type FormatType = 'sharegpt' | 'openai';

export type AppMode = 'landing' | 'manual' | 'synthetic';

export interface ShareGPTMessage {
  from: 'system' | 'human' | 'gpt';
  value: string;
}

export interface ShareGPTEntry {
  conversations: ShareGPTMessage[];
}

export interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface OpenAIEntry {
  messages: OpenAIMessage[];
}

export type DatasetEntry = ShareGPTEntry | OpenAIEntry;

export interface AppConfig {
  format: FormatType;
  useFixedSystemPrompt: boolean;
  fixedSystemPrompt: string;
  targetCount: number;
  filename: string;
}

// Para modo single-turn (legacy)
export interface FormState {
  system: string;
  user: string;
  assistant: string;
}

// Para modo multi-turn
export interface ConversationTurn {
  role: 'human' | 'gpt';
  content: string;
}

export interface MultiTurnFormState {
  system: string;
  turns: ConversationTurn[];
}