import React from 'react';

// --- LABEL ---
export interface LabelProps {
  children?: React.ReactNode;
  htmlFor?: string;
  className?: string;
}
export const Label: React.FC<LabelProps> = ({ children, htmlFor, className = "" }) => (
  <label htmlFor={htmlFor} className={`block text-sm font-medium text-slate-400 mb-1.5 ${className}`}>
    {children}
  </label>
);

// --- INPUT ---
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}
export const Input = React.forwardRef<HTMLInputElement, InputProps>(({ className = "", ...props }, ref) => (
  <input
    ref={ref}
    className={`w-full bg-slate-900 border border-slate-700 text-slate-100 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 placeholder-slate-500 focus:outline-none transition-colors ${className}`}
    {...props}
  />
));

// --- TEXTAREA ---
export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}
export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(({ className = "", ...props }, ref) => (
  <textarea
    ref={ref}
    className={`w-full bg-slate-900 border border-slate-700 text-slate-100 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-3 placeholder-slate-500 focus:outline-none transition-colors scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent ${className}`}
    {...props}
  />
));

// --- SELECT ---
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {}
export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(({ className = "", children, ...props }, ref) => (
  <select
    ref={ref}
    className={`w-full bg-slate-900 border border-slate-700 text-slate-100 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 focus:outline-none transition-colors ${className}`}
    {...props}
  >
    {children}
  </select>
));

// --- BUTTON ---
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  // Explicitly defining these to avoid TS errors in strict environments
  className?: string;
  children?: React.ReactNode;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
}
export const Button: React.FC<ButtonProps> = ({ children, className = "", variant = 'primary', size = 'md', ...props }) => {
  const base = "inline-flex items-center justify-center font-medium rounded-lg focus:outline-none transition-all duration-200";
  
  const variants = {
    primary: "text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 shadow-sm shadow-blue-500/20",
    secondary: "text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700",
    danger: "text-white bg-red-600 hover:bg-red-700",
    ghost: "text-slate-400 hover:text-white hover:bg-slate-800",
  };
  
  const sizes = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-5 py-3 text-base",
  };

  return (
    <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...props}>
      {children}
    </button>
  );
};

// --- TOGGLE SWITCH ---
export interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
}
export const Toggle: React.FC<ToggleProps> = ({ checked, onChange, label }) => (
  <div className="flex items-center justify-between cursor-pointer group" onClick={() => onChange(!checked)}>
    {label && <span className="text-sm font-medium text-slate-300 group-hover:text-white transition-colors">{label}</span>}
    <div className={`relative w-11 h-6 bg-slate-700 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-800 transition-colors ${checked ? 'bg-blue-600' : ''}`}>
      <div className={`absolute top-0.5 left-[2px] bg-white border-gray-300 border rounded-full h-5 w-5 transition-transform ${checked ? 'translate-x-full border-white' : ''}`}></div>
    </div>
  </div>
);

// --- CARD ---
export interface CardProps {
  children?: React.ReactNode;
  className?: string;
}
export const Card: React.FC<CardProps> = ({ children, className = "" }) => (
  <div className={`bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden ${className}`}>
    {children}
  </div>
);