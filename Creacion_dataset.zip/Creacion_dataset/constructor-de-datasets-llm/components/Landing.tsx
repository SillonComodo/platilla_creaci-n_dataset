import React from 'react';
import { AppMode } from '../types';
import { IconPen, IconBrain } from './Icons';

interface LandingProps {
  onSelectMode: (mode: AppMode) => void;
}

export const Landing: React.FC<LandingProps> = ({ onSelectMode }) => {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-4 tracking-tight">
          Dataset Builder
        </h1>
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto">
          Crea datasets de alta calidad para fine-tuning de LLMs. Elige cómo quieres trabajar hoy.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        {/* Manual Card */}
        <button 
          onClick={() => onSelectMode('manual')}
          className="group relative bg-slate-900/50 hover:bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-2xl hover:shadow-blue-500/10 flex flex-col"
        >
          <div className="bg-slate-800 rounded-xl p-4 w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
            <IconPen className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">Modo Manual</h2>
          <p className="text-slate-400 leading-relaxed">
            Control total. Escribe cada prompt y respuesta a mano. Ideal para crear ejemplos "Golden" de alta precisión o corregir casos de borde específicos.
          </p>
        </button>

        {/* Synthetic Card */}
        <button 
          onClick={() => onSelectMode('synthetic')}
          className="group relative bg-slate-900/50 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/10 flex flex-col"
        >
          <div className="bg-slate-800 rounded-xl p-4 w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-purple-600 transition-colors">
            <IconBrain className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">Modo Sintético (IA)</h2>
          <p className="text-slate-400 leading-relaxed">
            Automatización total. Define una tarea y deja que OpenAI genere ejemplos variados por ti. Perfecto para escalar tu dataset rápidamente.
          </p>
          <div className="absolute top-4 right-4 px-3 py-1 bg-purple-500/20 border border-purple-500/30 rounded-full text-xs text-purple-300 font-mono font-bold">
            OPENAI POWERED
          </div>
        </button>
      </div>
    </div>
  );
};