import React from 'react';
import { DatasetEntry, FormatType } from '../types';
import { Card, Button } from './UI';
import { IconTrash, IconFileJson } from './Icons';

interface PreviewListProps {
  dataset: DatasetEntry[];
  onRemove: (index: number) => void;
  format: FormatType;
}

export const PreviewList: React.FC<PreviewListProps> = ({ dataset, onRemove, format }) => {
  // Show last 3 items, reversed
  const recentItems = [...dataset].map((item, idx) => ({ item, originalIndex: idx })).reverse().slice(0, 3);
  
  if (dataset.length === 0) {
    return (
      <div className="text-center py-20 opacity-50 border-2 border-dashed border-slate-800 rounded-xl">
        <IconFileJson className="w-16 h-16 mx-auto mb-4 text-slate-600" />
        <p className="text-slate-400 text-lg">El dataset está vacío.</p>
        <p className="text-slate-600 text-sm">Añade tu primer ejemplo para comenzar.</p>
      </div>
    );
  }

  // Helper to extract preview text safely regardless of format
  const getPreviewText = (entry: DatasetEntry) => {
    if ('conversations' in entry) {
      // ShareGPT
      const userMsg = entry.conversations.find(c => c.from === 'human')?.value;
      const botMsg = entry.conversations.find(c => c.from === 'gpt')?.value;
      return { user: userMsg, bot: botMsg };
    } else {
      // OpenAI
      const userMsg = entry.messages.find(m => m.role === 'user')?.content;
      const botMsg = entry.messages.find(m => m.role === 'assistant')?.content;
      return { user: userMsg, bot: botMsg };
    }
  };

  const lastItem = dataset[dataset.length - 1];

  return (
    <div className="space-y-8">
      {/* Raw JSON Preview of Latest */}
      <section>
        <div className="flex items-center space-x-2 mb-4">
          <IconFileJson className="text-yellow-500 w-5 h-5" />
          <h3 className="text-lg font-medium text-white">Vista Previa JSON (Último)</h3>
        </div>
        <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 overflow-x-auto shadow-inner">
          <pre className="text-xs md:text-sm font-mono text-green-400 whitespace-pre-wrap break-all">
            {JSON.stringify(lastItem, null, 2)}
          </pre>
        </div>
      </section>

      {/* Recent List */}
      <section>
        <h3 className="text-lg font-medium text-white mb-4">Entradas Recientes</h3>
        <div className="space-y-4">
          {recentItems.map(({ item, originalIndex }) => {
            const { user, bot } = getPreviewText(item);
            return (
              <Card key={originalIndex} className="p-4 group hover:border-slate-600 transition-colors">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-1 rounded">
                    Índice #{originalIndex + 1}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => onRemove(originalIndex)}
                    className="text-slate-500 hover:text-red-400 -mt-1 -mr-1"
                  >
                    <IconTrash className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="space-y-3">
                  <div className="pl-3 border-l-2 border-blue-500/30">
                    <p className="text-xs text-blue-400 font-bold mb-1 uppercase">Usuario</p>
                    <p className="text-sm text-slate-300 line-clamp-2 font-medium">{user || '(Sin contenido)'}</p>
                  </div>
                  <div className="pl-3 border-l-2 border-emerald-500/30">
                    <p className="text-xs text-emerald-400 font-bold mb-1 uppercase">Asistente</p>
                    <p className="text-sm text-slate-400 line-clamp-2 font-mono">{bot || '(Sin contenido)'}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
        {dataset.length > 3 && (
          <p className="text-center text-xs text-slate-500 mt-4">
            ... y {dataset.length - 3} ítems más ocultos.
          </p>
        )}
      </section>
    </div>
  );
};