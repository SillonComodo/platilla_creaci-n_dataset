import React, { useState, useEffect } from 'react';
import { AppConfig, FormState, DatasetEntry, ShareGPTEntry, OpenAIEntry, ConversationTurn } from '../types';
import { Button, Textarea, Label, Card, Toggle } from './UI';
import { IconPlus, IconBot, IconUser, IconSettings, IconTrash, IconMessageCircle, IconRefresh } from './Icons';

interface FormProps {
  config: AppConfig;
  onAdd: (entry: DatasetEntry) => void;
}

export const DataEntryForm: React.FC<FormProps> = ({ config, onAdd }) => {
  // Multi-turn state
  const [isMultiTurn, setIsMultiTurn] = useState(true);
  const [systemPrompt, setSystemPrompt] = useState('');
  const [turns, setTurns] = useState<ConversationTurn[]>([
    { role: 'human', content: '' },
    { role: 'gpt', content: '' }
  ]);
  
  // Single-turn legacy state
  const [form, setForm] = useState<FormState>({
    system: '',
    user: '',
    assistant: ''
  });

  const [errors, setErrors] = useState<Record<string, boolean>>({});

  // Reset local system prompt if we switch to fixed
  useEffect(() => {
    if (config.useFixedSystemPrompt) {
      setForm(prev => ({ ...prev, system: '' }));
      setSystemPrompt('');
    }
  }, [config.useFixedSystemPrompt]);

  // --- Multi-turn handlers ---
  const addTurn = (role: 'human' | 'gpt') => {
    setTurns(prev => [...prev, { role, content: '' }]);
  };

  const removeTurn = (index: number) => {
    if (turns.length <= 2) return; // Keep at least one pair
    setTurns(prev => prev.filter((_, i) => i !== index));
  };

  const updateTurn = (index: number, content: string) => {
    setTurns(prev => prev.map((turn, i) => i === index ? { ...turn, content } : turn));
    if (errors[`turn-${index}`]) {
      setErrors(prev => ({ ...prev, [`turn-${index}`]: false }));
    }
  };

  const resetConversation = () => {
    setTurns([
      { role: 'human', content: '' },
      { role: 'gpt', content: '' }
    ]);
    setSystemPrompt('');
    setErrors({});
  };

  // --- Submit handlers ---
  const handleSubmitMultiTurn = () => {
    // Validate all turns have content
    const newErrors: Record<string, boolean> = {};
    turns.forEach((turn, i) => {
      if (!turn.content.trim()) {
        newErrors[`turn-${i}`] = true;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const sysPrompt = config.useFixedSystemPrompt ? config.fixedSystemPrompt : systemPrompt;
    
    let newEntry: DatasetEntry;

    if (config.format === 'sharegpt') {
      const conversations: ShareGPTEntry['conversations'] = [];
      if (sysPrompt.trim()) conversations.push({ from: 'system', value: sysPrompt });
      turns.forEach(turn => {
        conversations.push({ 
          from: turn.role === 'human' ? 'human' : 'gpt', 
          value: turn.content 
        });
      });
      newEntry = { conversations };
    } else {
      const messages: OpenAIEntry['messages'] = [];
      if (sysPrompt.trim()) messages.push({ role: 'system', content: sysPrompt });
      turns.forEach(turn => {
        messages.push({ 
          role: turn.role === 'human' ? 'user' : 'assistant', 
          content: turn.content 
        });
      });
      newEntry = { messages };
    }

    onAdd(newEntry);
    resetConversation();
  };

  const handleSubmitSingleTurn = () => {
    const newErrors = {
      user: !form.user.trim(),
      assistant: !form.assistant.trim()
    };

    if (newErrors.user || newErrors.assistant) {
      setErrors(newErrors);
      return;
    }

    const sysPrompt = config.useFixedSystemPrompt ? config.fixedSystemPrompt : form.system;
    
    let newEntry: DatasetEntry;

    if (config.format === 'sharegpt') {
      const conversations: ShareGPTEntry['conversations'] = [];
      if (sysPrompt.trim()) conversations.push({ from: 'system', value: sysPrompt });
      conversations.push({ from: 'human', value: form.user });
      conversations.push({ from: 'gpt', value: form.assistant });
      newEntry = { conversations };
    } else {
      const messages: OpenAIEntry['messages'] = [];
      if (sysPrompt.trim()) messages.push({ role: 'system', content: sysPrompt });
      messages.push({ role: 'user', content: form.user });
      messages.push({ role: 'assistant', content: form.assistant });
      newEntry = { messages };
    }

    onAdd(newEntry);
    setForm({
      system: config.useFixedSystemPrompt ? '' : form.system, 
      user: '',
      assistant: ''
    });
  };

  const handleChange = (field: keyof FormState, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: false }));
    }
  };

  // Labels based on format
  const userLabel = config.format === 'sharegpt' ? 'Human' : 'Usuario';
  const botLabel = config.format === 'sharegpt' ? 'GPT' : 'Asistente';

  return (
    <Card className="p-6 mb-8 border-slate-700 bg-slate-900 shadow-xl shadow-black/20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-white flex items-center">
          <IconMessageCircle className="w-5 h-5 mr-2 text-blue-400" />
          Nuevo Ejemplo
        </h2>
        <div className="flex items-center gap-4">
          <Toggle
            label="Multi-turno"
            checked={isMultiTurn}
            onChange={setIsMultiTurn}
          />
          <div className="text-xs text-slate-500 uppercase tracking-wider font-bold">
            {config.format}
          </div>
        </div>
      </div>

      {/* Multi-turn Mode */}
      {isMultiTurn ? (
        <div className="space-y-4">
          {/* System Prompt */}
          {!config.useFixedSystemPrompt && (
            <div className="animate-fadeIn">
              <div className="flex items-center space-x-2 mb-2">
                <IconSettings className="w-4 h-4 text-purple-400" />
                <Label className="!mb-0 text-purple-300">Instrucción del Sistema</Label>
              </div>
              <Textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                placeholder="Define el rol y personalidad del asistente..."
                rows={2}
                className="border-slate-700 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
          )}

          {/* Conversation Turns */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="!mb-0 text-slate-300">Conversación ({turns.length} turnos)</Label>
              <button
                onClick={resetConversation}
                className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1"
              >
                <IconRefresh className="w-3 h-3" />
                Reiniciar
              </button>
            </div>

            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700">
              {turns.map((turn, index) => (
                <div 
                  key={index} 
                  className={`relative p-3 rounded-lg border ${
                    turn.role === 'human' 
                      ? 'bg-blue-950/30 border-blue-800/50' 
                      : 'bg-emerald-950/30 border-emerald-800/50'
                  } ${errors[`turn-${index}`] ? 'border-red-500' : ''}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {turn.role === 'human' ? (
                        <IconUser className="w-4 h-4 text-blue-400" />
                      ) : (
                        <IconBot className="w-4 h-4 text-emerald-400" />
                      )}
                      <span className={`text-xs font-bold uppercase ${
                        turn.role === 'human' ? 'text-blue-400' : 'text-emerald-400'
                      }`}>
                        {turn.role === 'human' ? userLabel : botLabel}
                      </span>
                      <span className="text-xs text-slate-600">#{index + 1}</span>
                    </div>
                    {turns.length > 2 && (
                      <button
                        onClick={() => removeTurn(index)}
                        className="text-slate-500 hover:text-red-400 p-1"
                      >
                        <IconTrash className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <Textarea
                    value={turn.content}
                    onChange={(e) => updateTurn(index, e.target.value)}
                    placeholder={turn.role === 'human' 
                      ? 'Mensaje del usuario...' 
                      : 'Respuesta del asistente...'}
                    rows={2}
                    className={`bg-transparent border-0 p-0 focus:ring-0 resize-none ${
                      turn.role === 'gpt' ? 'font-mono text-sm' : ''
                    }`}
                  />
                  {errors[`turn-${index}`] && (
                    <p className="text-red-500 text-xs mt-1">Este turno no puede estar vacío.</p>
                  )}
                </div>
              ))}
            </div>

            {/* Add turn buttons */}
            <div className="flex gap-2 pt-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => addTurn('human')}
                className="flex-1"
              >
                <IconUser className="w-3 h-3 mr-1" />
                + {userLabel}
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => addTurn('gpt')}
                className="flex-1"
              >
                <IconBot className="w-3 h-3 mr-1" />
                + {botLabel}
              </Button>
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end pt-4 border-t border-slate-800">
            <Button onClick={handleSubmitMultiTurn} size="lg" className="w-full md:w-auto px-8">
              <IconPlus className="w-5 h-5 mr-2" />
              Añadir Conversación
            </Button>
          </div>
        </div>
      ) : (
        /* Single-turn Mode (Legacy) */
        <div className="space-y-6">
          {!config.useFixedSystemPrompt && (
            <div className="animate-fadeIn">
              <div className="flex items-center space-x-2 mb-2">
                <IconSettings className="w-4 h-4 text-purple-400" />
                <Label className="!mb-0 text-purple-300">Instrucción del Sistema</Label>
              </div>
              <Textarea
                value={form.system}
                onChange={(e) => handleChange('system', e.target.value)}
                placeholder="Define el comportamiento del asistente..."
                rows={3}
                className="border-slate-700 focus:border-purple-500 focus:ring-purple-500/20"
              />
            </div>
          )}

          <div>
            <div className="flex items-center space-x-2 mb-2">
              <IconUser className="w-4 h-4 text-blue-400" />
              <Label className="!mb-0 text-blue-300">{userLabel} <span className="text-red-500">*</span></Label>
            </div>
            <Textarea
              value={form.user}
              onChange={(e) => handleChange('user', e.target.value)}
              placeholder="Escribe el prompt de entrada..."
              rows={5}
              className={`${errors.user ? 'border-red-500' : ''}`}
            />
            {errors.user && <p className="text-red-500 text-xs mt-1">Campo obligatorio.</p>}
          </div>

          <div>
            <div className="flex items-center space-x-2 mb-2">
              <IconBot className="w-4 h-4 text-emerald-400" />
              <Label className="!mb-0 text-emerald-300">{botLabel} <span className="text-red-500">*</span></Label>
            </div>
            <Textarea
              value={form.assistant}
              onChange={(e) => handleChange('assistant', e.target.value)}
              placeholder="Escribe la respuesta ideal..."
              rows={8}
              className={`font-mono text-sm bg-slate-950/50 ${errors.assistant ? 'border-red-500' : ''}`}
            />
            {errors.assistant && <p className="text-red-500 text-xs mt-1">Campo obligatorio.</p>}
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-800">
            <Button onClick={handleSubmitSingleTurn} size="lg" className="w-full md:w-auto px-8">
              <IconPlus className="w-5 h-5 mr-2" />
              Añadir Ejemplo
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
};
