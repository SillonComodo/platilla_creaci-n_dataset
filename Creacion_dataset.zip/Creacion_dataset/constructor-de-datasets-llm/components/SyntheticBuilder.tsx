import React, { useState, useCallback, useRef } from 'react';
import OpenAI from "openai";
import { AppConfig, DatasetEntry, ShareGPTEntry, OpenAIEntry } from '../types';
import { Card, Label, Textarea, Button, Input, Select, Toggle } from './UI';
import { IconBrain, IconSettings, IconMessageCircle, IconPlus, IconTrash, IconFileJson, IconSwapHorizontal } from './Icons';

// Modelos disponibles de OpenAI
const OPENAI_MODELS = [
  { id: 'gpt-5-nano-2025-08-07', name: 'GPT-5 Nano (Más reciente)' },
  { id: 'gpt-4.1-mini', name: 'GPT-4.1 Mini (Rápido y económico)' },
  { id: 'gpt-4.1', name: 'GPT-4.1 (Equilibrado)' },
  { id: 'gpt-4o', name: 'GPT-4o (Potente)' },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
  { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo (Más económico)' },
];

interface StagedEntry {
  id: string;
  entry: DatasetEntry;
  isEditing: boolean;
  editedJson: string;
}

interface SyntheticBuilderProps {
  config: AppConfig;
  onAdd: (entries: DatasetEntry[]) => Promise<void> | void;
  datasetCount: number;
}

export const SyntheticBuilder: React.FC<SyntheticBuilderProps> = ({ config, onAdd, datasetCount }) => {
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  
  // Configuración de OpenAI / LM Studio
  const [apiKey, setApiKey] = useState(import.meta.env.VITE_OPENAI_API_KEY || '');
  const [selectedModel, setSelectedModel] = useState('gpt-4.1-mini');
  const [showSettings, setShowSettings] = useState(!import.meta.env.VITE_OPENAI_API_KEY);
  const [customEndpoint, setCustomEndpoint] = useState(''); // URL personalizada (LM Studio, etc.)
  const [isLocalServer, setIsLocalServer] = useState(false); // Si es servidor local
  
  // Configuración de generación por lotes
  const [batchSize, setBatchSize] = useState(1); // Cuántos ejemplos generar en total
  const [concurrentRequests, setConcurrentRequests] = useState(3); // Requests simultáneos (3 para OpenAI, 1 para local)
  const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 0 });
  
  // Multi-turn config
  const [isMultiTurn, setIsMultiTurn] = useState(true);
  const [minTurns, setMinTurns] = useState(3);
  const [maxTurns, setMaxTurns] = useState(6);
  
  // Ejemplos de referencia (few-shot)
  const [referenceExamples, setReferenceExamples] = useState<DatasetEntry[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Staging area - ejemplos generados pendientes de aprobar
  const [stagedEntries, setStagedEntries] = useState<StagedEntry[]>([]);
  const [currentStagedIndex, setCurrentStagedIndex] = useState(0);

  const addLog = (msg: string) => setLogs(prev => [msg, ...prev].slice(0, 5));

  // --- Drag & Drop handlers ---
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const parseJsonFile = async (file: File): Promise<DatasetEntry[]> => {
    const text = await file.text();
    const entries: DatasetEntry[] = [];
    
    // Intentar parsear como JSON array primero
    try {
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed)) {
        return parsed;
      } else if (parsed.conversations || parsed.messages) {
        return [parsed];
      }
    } catch {
      // Intentar parsear como JSONL
      const lines = text.split('\n').filter(line => line.trim());
      for (const line of lines) {
        try {
          const obj = JSON.parse(line);
          if (obj.conversations || obj.messages) {
            entries.push(obj);
          }
        } catch {
          // Ignorar líneas inválidas
        }
      }
    }
    return entries;
  };

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const jsonFiles = files.filter((f): f is File => f instanceof File && (f.name.endsWith('.json') || f.name.endsWith('.jsonl')));
    
    if (jsonFiles.length === 0) {
      addLog("⚠️ Arrastra archivos .json o .jsonl");
      return;
    }
    
    let totalLoaded = 0;
    for (const file of jsonFiles) {
      const entries = await parseJsonFile(file);
      setReferenceExamples(prev => [...prev, ...entries]);
      totalLoaded += entries.length;
    }
    addLog(`✓ Cargados ${totalLoaded} ejemplos de referencia`);
  }, []);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    let totalLoaded = 0;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const entries = await parseJsonFile(file);
      setReferenceExamples(prev => [...prev, ...entries]);
      totalLoaded += entries.length;
    }
    addLog(`✓ Cargados ${totalLoaded} ejemplos de referencia`);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearReferenceExamples = () => {
    setReferenceExamples([]);
    addLog("Ejemplos de referencia eliminados");
  };

  // --- Staging handlers ---
  const addToStaging = (entry: DatasetEntry) => {
    const newStaged: StagedEntry = {
      id: crypto.randomUUID(),
      entry,
      isEditing: false,
      editedJson: JSON.stringify(entry, null, 2)
    };
    setStagedEntries(prev => [...prev, newStaged]);
  };

  const removeFromStaging = (id: string) => {
    setStagedEntries(prev => {
      const newList = prev.filter(e => e.id !== id);
      if (currentStagedIndex >= newList.length && newList.length > 0) {
        setCurrentStagedIndex(newList.length - 1);
      }
      return newList;
    });
  };

  const toggleEditStaged = (id: string) => {
    setStagedEntries(prev => prev.map(e => 
      e.id === id ? { ...e, isEditing: !e.isEditing } : e
    ));
  };

  const updateStagedJson = (id: string, json: string) => {
    setStagedEntries(prev => prev.map(e => 
      e.id === id ? { ...e, editedJson: json } : e
    ));
  };

  const saveEditedStaged = (id: string) => {
    setStagedEntries(prev => prev.map(e => {
      if (e.id !== id) return e;
      try {
        const parsed = JSON.parse(e.editedJson);
        return { ...e, entry: parsed, isEditing: false };
      } catch {
        addLog("⚠️ JSON inválido, revisa la sintaxis");
        return e;
      }
    }));
  };

  // Actualizar un mensaje específico en el staged entry
  const updateStagedMessage = (id: string, messageIndex: number, newValue: string) => {
    setStagedEntries(prev => prev.map(e => {
      if (e.id !== id) return e;
      const updatedEntry = { ...e.entry };
      
      if ('conversations' in updatedEntry) {
        updatedEntry.conversations = [...updatedEntry.conversations];
        updatedEntry.conversations[messageIndex] = {
          ...updatedEntry.conversations[messageIndex],
          value: newValue
        };
      } else {
        updatedEntry.messages = [...updatedEntry.messages];
        updatedEntry.messages[messageIndex] = {
          ...updatedEntry.messages[messageIndex],
          content: newValue
        };
      }
      
      return { 
        ...e, 
        entry: updatedEntry,
        editedJson: JSON.stringify(updatedEntry, null, 2)
      };
    }));
  };

  // Intercambiar rol de un mensaje (human ↔ gpt)
  const swapMessageRole = (id: string, messageIndex: number) => {
    setStagedEntries(prev => prev.map(e => {
      if (e.id !== id) return e;
      const updatedEntry = { ...e.entry };
      
      if ('conversations' in updatedEntry) {
        updatedEntry.conversations = [...updatedEntry.conversations];
        const current = updatedEntry.conversations[messageIndex];
        if (current.from === 'human') {
          updatedEntry.conversations[messageIndex] = { ...current, from: 'gpt' };
        } else if (current.from === 'gpt') {
          updatedEntry.conversations[messageIndex] = { ...current, from: 'human' };
        }
        // No intercambiar 'system'
      } else {
        updatedEntry.messages = [...updatedEntry.messages];
        const current = updatedEntry.messages[messageIndex];
        if (current.role === 'user') {
          updatedEntry.messages[messageIndex] = { ...current, role: 'assistant' };
        } else if (current.role === 'assistant') {
          updatedEntry.messages[messageIndex] = { ...current, role: 'user' };
        }
        // No intercambiar 'system'
      }
      
      return { 
        ...e, 
        entry: updatedEntry,
        editedJson: JSON.stringify(updatedEntry, null, 2)
      };
    }));
  };

  // Eliminar un mensaje del staged entry
  const deleteMessageFromStaged = (id: string, messageIndex: number) => {
    setStagedEntries(prev => prev.map(e => {
      if (e.id !== id) return e;
      const updatedEntry = { ...e.entry };
      
      if ('conversations' in updatedEntry) {
        updatedEntry.conversations = updatedEntry.conversations.filter((_, i) => i !== messageIndex);
      } else {
        updatedEntry.messages = updatedEntry.messages.filter((_, i) => i !== messageIndex);
      }
      
      return { 
        ...e, 
        entry: updatedEntry,
        editedJson: JSON.stringify(updatedEntry, null, 2)
      };
    }));
  };

  const acceptAllStaged = async () => {
    if (stagedEntries.length === 0) return;
    const entries = stagedEntries.map(s => s.entry);
    await onAdd(entries);
    setStagedEntries([]);
    setCurrentStagedIndex(0);
    addLog(`✓ ${entries.length} ejemplos añadidos al dataset`);
  };

  const acceptCurrentStaged = async () => {
    if (stagedEntries.length === 0) return;
    const current = stagedEntries[currentStagedIndex];
    if (!current) return;
    
    await onAdd([current.entry]);
    removeFromStaging(current.id);
    addLog("✓ Ejemplo añadido al dataset");
  };

  // --- Generation ---
  const generateSingleExample = async (client: OpenAI): Promise<DatasetEntry | null> => {
    // Define Schema based on format
    const responseSchema = config.format === 'sharegpt'
      ? {
          type: "object",
          properties: {
            conversations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  from: { type: "string", enum: ["human", "gpt", "system"] },
                  value: { type: "string" }
                },
                required: ["from", "value"],
                additionalProperties: false
              }
            }
          },
          required: ["conversations"],
          additionalProperties: false
        }
      : {
          type: "object",
          properties: {
            messages: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  role: { type: "string", enum: ["user", "assistant", "system"] },
                  content: { type: "string" }
                },
                required: ["role", "content"],
                additionalProperties: false
              }
            }
          },
          required: ["messages"],
          additionalProperties: false
        };

    const systemContext = config.useFixedSystemPrompt 
      ? `Instrucción del sistema global para incluir al inicio: "${config.fixedSystemPrompt}".` 
      : 'Genera un system prompt apropiado para la tarea.';
    
    const multiTurnInstruction = isMultiTurn 
      ? `IMPORTANTE: Genera una conversación MULTI-TURNO con ${minTurns}-${maxTurns} intercambios (pares human-gpt). Simula un diálogo real donde el usuario hace preguntas de seguimiento.`
      : 'Genera un ejemplo de un solo turno (1 pregunta, 1 respuesta).';
    
    const formatInstruction = config.format === 'sharegpt'
      ? 'Usa formato ShareGPT: { conversations: [{ from: "system"|"human"|"gpt", value: "..." }] }'
      : 'Usa formato OpenAI: { messages: [{ role: "system"|"user"|"assistant", content: "..." }] }';

    // Few-shot examples
    let fewShotSection = '';
    if (referenceExamples.length > 0) {
      const samplesToUse = referenceExamples.slice(0, 3);
      fewShotSection = `
EJEMPLOS DE REFERENCIA (genera ejemplos similares en estilo y formato):
${samplesToUse.map((ex, i) => `Ejemplo ${i + 1}:\n${JSON.stringify(ex, null, 2)}`).join('\n\n')}

Genera un NUEVO ejemplo diferente pero con el mismo estilo y formato.`;
    }

    const messages = [
      {
        role: 'system' as const,
        content: `Eres un generador experto de datos de entrenamiento para fine-tuning de LLMs. Creas conversaciones realistas y de alta calidad. Responde SOLO con JSON válido. ${formatInstruction}`
      },
      {
        role: 'user' as const,
        content: `Genera 1 ejemplo de entrenamiento sobre: "${topic}".
        
${systemContext}

${multiTurnInstruction}
${fewShotSection}

Requisitos:
- Conversación natural y realista
- Mantén el contexto entre turnos
- Variedad en las respuestas
- Solo JSON, sin texto extra`
      }
    ];

    try {
      // Para servidores locales, no usar json_schema estricto
      const completionParams: Parameters<typeof client.chat.completions.create>[0] = {
        model: selectedModel,
        messages,
      };

      // Solo usar json_schema si no es servidor local (LM Studio no lo soporta bien)
      if (!isLocalServer) {
        completionParams.response_format = {
          type: 'json_schema',
          json_schema: {
            name: 'dataset_entry',
            schema: responseSchema,
            strict: true
          }
        };
      }
      // Para servidor local, NO usar response_format - algunos modelos locales no lo soportan bien
      // El prompt ya pide JSON explícitamente

      const completion = await client.chat.completions.create(completionParams);

      const content = completion.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error('El modelo no devolvió contenido');
      }
      
      // Intentar extraer JSON del contenido (a veces el modelo añade texto extra)
      let jsonContent = content.trim();
      
      // Si hay texto antes del JSON, intentar extraerlo
      const jsonStart = jsonContent.indexOf('{');
      const jsonEnd = jsonContent.lastIndexOf('}');
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonStart < jsonEnd) {
        jsonContent = jsonContent.substring(jsonStart, jsonEnd + 1);
      }
      
      try {
        return JSON.parse(jsonContent);
      } catch (parseError) {
        console.error('Error parseando JSON:', jsonContent.substring(0, 200));
        throw new Error('Respuesta no es JSON válido');
      }
    } catch (error) {
      console.error('Error generando ejemplo:', error);
      // Detectar errores de CORS
      const errorMsg = (error as Error).message || String(error);
      if (errorMsg.includes('Failed to fetch') || errorMsg.includes('NetworkError') || errorMsg.includes('CORS')) {
        throw new Error('CORS: Habilita "Enable CORS" en LM Studio Server settings');
      }
      throw error;
    }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    if (!apiKey.trim() && !isLocalServer) {
      addLog("⚠️ Ingresa tu API Key.");
      setShowSettings(true);
      return;
    }
    
    if (datasetCount + stagedEntries.length >= config.targetCount) {
      addLog("¡Objetivo alcanzado! Aumenta el objetivo para generar más.");
      return;
    }

    setIsGenerating(true);
    setGenerationProgress({ current: 0, total: batchSize });
    
    const serverUrl = customEndpoint.trim() || undefined;
    addLog(`Generando ${batchSize} ejemplo(s) con ${selectedModel}...`);
    if (serverUrl) {
      addLog(`→ Servidor: ${serverUrl}`);
    }

    try {
      const clientConfig: ConstructorParameters<typeof OpenAI>[0] = {
        apiKey: apiKey.trim() || 'lm-studio', // LM Studio no requiere API key real
        dangerouslyAllowBrowser: true,
      };
      
      if (serverUrl) {
        clientConfig.baseURL = serverUrl;
      }
      
      const client = new OpenAI(clientConfig);
      
      // Determinar concurrencia (1 para local, configurable para OpenAI)
      const actualConcurrency = isLocalServer ? 1 : concurrentRequests;
      
      let successCount = 0;
      let errorCount = 0;
      let lastError = '';
      
      // Generar en lotes (secuencial para servidores locales)
      for (let i = 0; i < batchSize; i += actualConcurrency) {
        const batchPromises: Promise<DatasetEntry | null>[] = [];
        const currentBatchSize = Math.min(actualConcurrency, batchSize - i);
        
        // Para servidor local, generar uno a uno con más pausa
        if (isLocalServer) {
          addLog(`→ Generando ejemplo ${i + 1}/${batchSize}...`);
        }
        
        for (let j = 0; j < currentBatchSize; j++) {
          batchPromises.push(generateSingleExample(client));
        }
        
        const results = await Promise.allSettled(batchPromises);
        
        for (const result of results) {
          if (result.status === 'fulfilled' && result.value) {
            addToStaging(result.value);
            successCount++;
            if (isLocalServer) {
              addLog(`✓ Ejemplo ${successCount} generado`);
            }
          } else {
            errorCount++;
            if (result.status === 'rejected') {
              lastError = (result.reason as Error).message || 'Error desconocido';
              console.error('Error en generación:', result.reason);
              addLog(`⚠️ Error: ${lastError.substring(0, 50)}...`);
            }
          }
          setGenerationProgress(prev => ({ ...prev, current: prev.current + 1 }));
        }
        
        // Si todos fallan con CORS, parar inmediatamente
        if (errorCount > 0 && successCount === 0 && lastError.includes('CORS')) {
          addLog(`❌ ${lastError}`);
          break;
        }
        
        // Pausa entre lotes - más larga para servidores locales
        if (i + actualConcurrency < batchSize) {
          const delay = isLocalServer ? 2000 : 500; // 2 segundos para local
          await new Promise(r => setTimeout(r, delay));
        }
      }
      
      if (successCount > 0) {
        addLog(`✓ ${successCount}/${batchSize} ejemplo(s) generado(s) → revisar en carrusel`);
      }
      if (errorCount > 0 && !lastError.includes('CORS')) {
        addLog(`⚠️ ${errorCount} error(es) - revisa consola (F12)`);
      }

    } catch (error) {
      console.error(error);
      const errorMsg = (error as Error).message || String(error);
      if (errorMsg.includes('Failed to fetch') || errorMsg.includes('CORS')) {
        addLog("❌ Error CORS: Habilita 'Enable CORS' en LM Studio");
      } else {
        addLog("❌ Error: " + errorMsg.substring(0, 80));
      }
    } finally {
      setIsGenerating(false);
      setGenerationProgress({ current: 0, total: 0 });
    }
  };

  // --- Render helpers ---
  const getPreviewText = (entry: DatasetEntry) => {
    if ('conversations' in entry) {
      const human = entry.conversations.find(c => c.from === 'human')?.value || '';
      const gpt = entry.conversations.find(c => c.from === 'gpt')?.value || '';
      return { human, gpt, turns: entry.conversations.filter(c => c.from !== 'system').length };
    } else {
      const user = entry.messages.find(m => m.role === 'user')?.content || '';
      const assistant = entry.messages.find(m => m.role === 'assistant')?.content || '';
      return { human: user, gpt: assistant, turns: entry.messages.filter(m => m.role !== 'system').length };
    }
  };

  const currentStaged = stagedEntries[currentStagedIndex];

  return (
    <div className="space-y-6">
      {/* Main Generator Card */}
      <Card className="p-6 border-purple-900/50 bg-slate-900 shadow-xl shadow-purple-900/10 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex items-center justify-between mb-6 relative">
          <h2 className="text-xl font-semibold text-white flex items-center">
            <IconBrain className="mr-2 text-purple-400" />
            Generador Sintético
          </h2>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-lg transition-colors ${showSettings ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
              title="Configuración"
            >
              <IconSettings className="w-4 h-4" />
            </button>
            <div className={`text-xs uppercase tracking-wider font-bold border px-2 py-1 rounded ${
              isLocalServer 
                ? 'text-green-400 border-green-500/30' 
                : 'text-purple-400 border-purple-500/30'
            }`}>
              {isLocalServer ? '🖥️ Local' : 'OpenAI'}
            </div>
          </div>
        </div>

        <div className="space-y-6 relative">
          {/* Settings Panel */}
          {showSettings && (
            <div className="bg-slate-950/70 rounded-xl p-4 border border-purple-500/30 space-y-4 animate-fadeIn">
              <h3 className="text-sm font-semibold text-purple-300 flex items-center gap-2">
                <IconSettings className="w-4 h-4" />
                Configuración
              </h3>
              
              {/* Servidor / Endpoint */}
              <div className="space-y-3 pb-3 border-b border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-purple-300 font-medium">🖥️ Servidor Local (LM Studio)</span>
                  </div>
                  <Toggle 
                    checked={isLocalServer} 
                    onChange={(checked) => {
                      setIsLocalServer(checked);
                      if (checked) {
                        setConcurrentRequests(1); // Local = 1 request a la vez
                        if (!customEndpoint) {
                          setCustomEndpoint('http://localhost:1234/v1');
                        }
                      } else {
                        setConcurrentRequests(3); // OpenAI = 3 paralelos
                        setCustomEndpoint('');
                      }
                    }} 
                  />
                </div>
                
                {isLocalServer && (
                  <div>
                    <Label className="text-xs text-slate-400">URL del Servidor</Label>
                    <Input
                      value={customEndpoint}
                      onChange={(e) => setCustomEndpoint(e.target.value)}
                      placeholder="http://localhost:1234/v1"
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      LM Studio: http://localhost:1234/v1 | Ollama: http://localhost:11434/v1
                    </p>
                    <div className="mt-2 p-2 bg-yellow-900/20 border border-yellow-700/30 rounded text-xs text-yellow-300">
                      ⚠️ <strong>Importante:</strong> En LM Studio, habilita <strong>"Enable CORS"</strong> en Server → Settings para evitar errores de conexión.
                    </div>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-purple-300">API Key {isLocalServer && <span className="text-slate-500">(opcional)</span>}</Label>
                  <Input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder={isLocalServer ? "lm-studio" : "sk-..."}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="text-purple-300">Modelo</Label>
                  {isLocalServer ? (
                    <Input
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      placeholder="Nombre del modelo en LM Studio"
                      className="text-sm"
                    />
                  ) : (
                    <Select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                    >
                      {OPENAI_MODELS.map(model => (
                        <option key={model.id} value={model.id}>{model.name}</option>
                      ))}
                    </Select>
                  )}
                </div>
              </div>

              {/* Generación por lotes */}
              <div className="pt-3 border-t border-slate-700 space-y-3">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Generación por Lotes</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-slate-400">Ejemplos a generar</Label>
                    <Input
                      type="number"
                      min={1}
                      max={50}
                      value={batchSize}
                      onChange={(e) => setBatchSize(Math.max(1, Math.min(50, parseInt(e.target.value) || 1)))}
                      className="text-center"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">
                      Requests paralelos {isLocalServer && <span className="text-yellow-500">(1 para local)</span>}
                    </Label>
                    <Input
                      type="number"
                      min={1}
                      max={isLocalServer ? 1 : 10}
                      value={concurrentRequests}
                      onChange={(e) => setConcurrentRequests(Math.max(1, Math.min(isLocalServer ? 1 : 10, parseInt(e.target.value) || 1)))}
                      className="text-center"
                      disabled={isLocalServer}
                    />
                  </div>
                </div>
              </div>

              {/* Multi-turno */}
              <div className="pt-3 border-t border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <IconMessageCircle className="w-4 h-4 text-purple-400" />
                    <span className="text-sm text-purple-300 font-medium">Multi-turno</span>
                  </div>
                  <Toggle checked={isMultiTurn} onChange={setIsMultiTurn} />
                </div>
                
                {isMultiTurn && (
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Label className="text-xs text-slate-400">Mín turnos</Label>
                      <Input
                        type="number"
                        min={2}
                        max={10}
                        value={minTurns}
                        onChange={(e) => setMinTurns(Math.max(2, parseInt(e.target.value) || 2))}
                        className="text-center"
                      />
                    </div>
                    <div className="flex-1">
                      <Label className="text-xs text-slate-400">Máx turnos</Label>
                      <Input
                        type="number"
                        min={2}
                        max={15}
                        value={maxTurns}
                        onChange={(e) => setMaxTurns(Math.max(minTurns, parseInt(e.target.value) || 6))}
                        className="text-center"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Drop Zone for Reference Examples */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-4 transition-all ${
              isDragging 
                ? 'border-purple-500 bg-purple-500/10' 
                : referenceExamples.length > 0 
                  ? 'border-green-500/50 bg-green-500/5' 
                  : 'border-slate-700 hover:border-slate-600'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,.jsonl"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />
            
            {referenceExamples.length === 0 ? (
              <div className="text-center py-4">
                <IconFileJson className="w-8 h-8 mx-auto mb-2 text-slate-500" />
                <p className="text-sm text-slate-400 mb-2">
                  Arrastra un archivo .json o .jsonl con ejemplos de referencia
                </p>
                <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                >
                  O selecciona archivo
                </Button>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <IconFileJson className="w-5 h-5 text-green-400" />
                  <span className="text-sm text-green-300">
                    {referenceExamples.length} ejemplos de referencia cargados
                  </span>
                </div>
                <Button variant="ghost" size="sm" onClick={clearReferenceExamples}>
                  <IconTrash className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>

          {/* Topic Input */}
          <div>
            <Label className="text-purple-300">Descripción de la Tarea</Label>
            <Textarea 
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Ej. Conversación entre cliente y agente de streaming sobre problemas de pago..."
              rows={3}
              className="border-slate-700 focus:border-purple-500"
            />
          </div>

          {/* Logs */}
          {logs.length > 0 && (
            <div className="bg-slate-950/50 rounded-lg p-3 font-mono text-xs text-slate-400 border border-slate-800">
              {logs.map((log, i) => (
                <div key={i} className="mb-1 last:mb-0 border-l-2 border-purple-500/50 pl-2">
                  {log}
                </div>
              ))}
            </div>
          )}

          {/* Action Bar */}
          <div className="flex justify-between items-center pt-4 border-t border-slate-800">
            <div className="text-sm text-slate-400">
              Progreso: <span className="text-white font-bold">{datasetCount}</span>
              {stagedEntries.length > 0 && (
                <span className="text-yellow-400"> (+{stagedEntries.length} pendientes)</span>
              )}
              <span className="text-slate-500"> / {config.targetCount}</span>
            </div>
            <div className="flex items-center gap-3">
              {isGenerating && generationProgress.total > 0 && (
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-24 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-purple-500 transition-all duration-300"
                      style={{ width: `${(generationProgress.current / generationProgress.total) * 100}%` }}
                    />
                  </div>
                  <span className="text-purple-300 text-xs">
                    {generationProgress.current}/{generationProgress.total}
                  </span>
                </div>
              )}
              <Button 
                onClick={handleGenerate} 
                disabled={isGenerating || !topic || (!apiKey.trim() && !isLocalServer)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isGenerating ? (
                  <span className="animate-pulse">Generando {generationProgress.current}/{generationProgress.total}...</span>
                ) : (
                  <>
                    <IconBrain className="w-4 h-4 mr-2" />
                    Generar {batchSize > 1 ? `${batchSize} Ejemplos` : 'Ejemplo'}
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Staging Carousel */}
      {stagedEntries.length > 0 && (
        <Card className="p-6 border-yellow-900/50 bg-slate-900 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-yellow-300 flex items-center gap-2">
              📝 Ejemplos Pendientes ({stagedEntries.length})
            </h3>
            <Button 
              onClick={acceptAllStaged}
              className="bg-green-600 hover:bg-green-700"
            >
              <IconPlus className="w-4 h-4 mr-2" />
              Aceptar Todos ({stagedEntries.length})
            </Button>
          </div>

          {/* Carousel Navigation */}
          <div className="flex items-center gap-2 mb-4">
            <button
              onClick={() => setCurrentStagedIndex(Math.max(0, currentStagedIndex - 1))}
              disabled={currentStagedIndex === 0}
              className="p-2 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              ←
            </button>
            <div className="flex-1 text-center text-sm text-slate-400">
              {currentStagedIndex + 1} de {stagedEntries.length}
            </div>
            <button
              onClick={() => setCurrentStagedIndex(Math.min(stagedEntries.length - 1, currentStagedIndex + 1))}
              disabled={currentStagedIndex === stagedEntries.length - 1}
              className="p-2 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              →
            </button>
          </div>

          {/* Current Staged Entry */}
          {currentStaged && (
            <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800">
              {currentStaged.isEditing ? (
                <div className="space-y-3">
                  {/* Edición inline de mensajes */}
                  <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                    {(() => {
                      if ('conversations' in currentStaged.entry) {
                        return currentStaged.entry.conversations.map((msg, idx) => (
                          <div key={idx} className={`p-3 rounded-lg border ${
                            msg.from === 'system' 
                              ? 'bg-slate-800/50 border-slate-600' 
                              : msg.from === 'human' 
                                ? 'bg-blue-950/30 border-blue-700/50' 
                                : 'bg-emerald-950/30 border-emerald-700/50'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <span className={`text-xs font-bold uppercase ${
                                msg.from === 'system' ? 'text-slate-400' : 
                                msg.from === 'human' ? 'text-blue-400' : 'text-emerald-400'
                              }`}>
                                {msg.from}
                              </span>
                              <div className="flex gap-1">
                                {msg.from !== 'system' && (
                                  <button
                                    onClick={() => swapMessageRole(currentStaged.id, idx)}
                                    className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors"
                                    title={`Cambiar a ${msg.from === 'human' ? 'GPT' : 'Human'}`}
                                  >
                                    <IconSwapHorizontal className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                <button
                                  onClick={() => deleteMessageFromStaged(currentStaged.id, idx)}
                                  className="p-1.5 rounded bg-red-900/50 hover:bg-red-800 text-red-400 hover:text-red-300 transition-colors"
                                  title="Eliminar mensaje"
                                >
                                  <IconTrash className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <textarea
                              value={msg.value}
                              onChange={(e) => updateStagedMessage(currentStaged.id, idx, e.target.value)}
                              className="w-full bg-slate-900/50 border border-slate-700 rounded p-2 text-sm text-slate-200 resize-none focus:border-purple-500 focus:outline-none"
                              rows={Math.min(6, Math.max(2, msg.value.split('\n').length))}
                            />
                          </div>
                        ));
                      } else {
                        return currentStaged.entry.messages.map((msg, idx) => (
                          <div key={idx} className={`p-3 rounded-lg border ${
                            msg.role === 'system' 
                              ? 'bg-slate-800/50 border-slate-600' 
                              : msg.role === 'user' 
                                ? 'bg-blue-950/30 border-blue-700/50' 
                                : 'bg-emerald-950/30 border-emerald-700/50'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <span className={`text-xs font-bold uppercase ${
                                msg.role === 'system' ? 'text-slate-400' : 
                                msg.role === 'user' ? 'text-blue-400' : 'text-emerald-400'
                              }`}>
                                {msg.role === 'user' ? 'human' : msg.role === 'assistant' ? 'gpt' : msg.role}
                              </span>
                              <div className="flex gap-1">
                                {msg.role !== 'system' && (
                                  <button
                                    onClick={() => swapMessageRole(currentStaged.id, idx)}
                                    className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors"
                                    title={`Cambiar a ${msg.role === 'user' ? 'GPT' : 'Human'}`}
                                  >
                                    <IconSwapHorizontal className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                <button
                                  onClick={() => deleteMessageFromStaged(currentStaged.id, idx)}
                                  className="p-1.5 rounded bg-red-900/50 hover:bg-red-800 text-red-400 hover:text-red-300 transition-colors"
                                  title="Eliminar mensaje"
                                >
                                  <IconTrash className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <textarea
                              value={msg.content}
                              onChange={(e) => updateStagedMessage(currentStaged.id, idx, e.target.value)}
                              className="w-full bg-slate-900/50 border border-slate-700 rounded p-2 text-sm text-slate-200 resize-none focus:border-purple-500 focus:outline-none"
                              rows={Math.min(6, Math.max(2, msg.content.split('\n').length))}
                            />
                          </div>
                        ));
                      }
                    })()}
                  </div>
                  
                  {/* Opción para ver/editar JSON raw */}
                  <details className="mt-2">
                    <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-400">
                      Ver/Editar JSON completo
                    </summary>
                    <Textarea
                      value={currentStaged.editedJson}
                      onChange={(e) => updateStagedJson(currentStaged.id, e.target.value)}
                      rows={8}
                      className="font-mono text-xs mt-2"
                    />
                  </details>
                  
                  <div className="flex gap-2 pt-2 border-t border-slate-700">
                    <Button size="sm" onClick={() => saveEditedStaged(currentStaged.id)} className="bg-green-600 hover:bg-green-700">
                      ✓ Guardar Cambios
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => toggleEditStaged(currentStaged.id)}>
                      Cancelar
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="mb-3 space-y-2 max-h-64 overflow-y-auto pr-2">
                    {(() => {
                      if ('conversations' in currentStaged.entry) {
                        return currentStaged.entry.conversations.map((msg, idx) => (
                          <div key={idx} className={`p-2 rounded border-l-2 ${
                            msg.from === 'system' 
                              ? 'bg-slate-800/30 border-slate-500' 
                              : msg.from === 'human' 
                                ? 'bg-blue-950/30 border-blue-500' 
                                : 'bg-emerald-950/30 border-emerald-500'
                          }`}>
                            <p className={`text-xs mb-1 font-bold ${
                              msg.from === 'system' ? 'text-slate-400' : 
                              msg.from === 'human' ? 'text-blue-400' : 'text-emerald-400'
                            }`}>
                              {msg.from.toUpperCase()}:
                            </p>
                            <p className="text-sm text-slate-300 whitespace-pre-wrap break-words">
                              {msg.value.length > 200 ? msg.value.substring(0, 200) + '...' : msg.value}
                            </p>
                          </div>
                        ));
                      } else {
                        return currentStaged.entry.messages.map((msg, idx) => (
                          <div key={idx} className={`p-2 rounded border-l-2 ${
                            msg.role === 'system' 
                              ? 'bg-slate-800/30 border-slate-500' 
                              : msg.role === 'user' 
                                ? 'bg-blue-950/30 border-blue-500' 
                                : 'bg-emerald-950/30 border-emerald-500'
                          }`}>
                            <p className={`text-xs mb-1 font-bold ${
                              msg.role === 'system' ? 'text-slate-400' : 
                              msg.role === 'user' ? 'text-blue-400' : 'text-emerald-400'
                            }`}>
                              {(msg.role === 'user' ? 'HUMAN' : msg.role === 'assistant' ? 'GPT' : msg.role.toUpperCase())}:
                            </p>
                            <p className="text-sm text-slate-300 whitespace-pre-wrap break-words">
                              {msg.content.length > 200 ? msg.content.substring(0, 200) + '...' : msg.content}
                            </p>
                          </div>
                        ));
                      }
                    })()}
                  </div>
                  
                  <details className="mb-3">
                    <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-400">
                      Ver JSON completo
                    </summary>
                    <pre className="mt-2 text-xs font-mono text-green-400 bg-slate-950 p-3 rounded overflow-auto max-h-48">
                      {JSON.stringify(currentStaged.entry, null, 2)}
                    </pre>
                  </details>

                  <div className="flex gap-2">
                    <Button size="sm" onClick={acceptCurrentStaged} className="bg-green-600 hover:bg-green-700">
                      ✓ Aceptar
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => toggleEditStaged(currentStaged.id)}>
                      ✏️ Editar
                    </Button>
                    <Button size="sm" variant="danger" onClick={() => removeFromStaging(currentStaged.id)}>
                      ✗ Descartar
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Thumbnail Navigation */}
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
            {stagedEntries.map((staged, idx) => (
              <button
                key={staged.id}
                onClick={() => setCurrentStagedIndex(idx)}
                className={`flex-shrink-0 w-16 h-12 rounded border text-xs flex items-center justify-center transition-all ${
                  idx === currentStagedIndex 
                    ? 'border-yellow-500 bg-yellow-500/20 text-yellow-300' 
                    : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-600'
                }`}
              >
                #{idx + 1}
              </button>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};
