import React from 'react';
import { AppConfig, FormatType } from '../types';
import { Input, Label, Select, Textarea, Toggle, Button } from './UI';
import { IconSettings, IconDownload } from './Icons';

interface SidebarProps {
  config: AppConfig;
  currentCount: number;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onDownload: () => void;
  onPickFile: () => void;
  fileStatus: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ config, currentCount, setConfig, onDownload, onPickFile, fileStatus }) => {
  const handleChange = (field: keyof AppConfig, value: any) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  const progress = Math.min((currentCount / (config.targetCount || 1)) * 100, 100);

  return (
    <aside className="w-full md:w-80 bg-slate-950 border-r border-slate-800 flex flex-col h-screen fixed left-0 top-0 z-20 md:relative">
      {/* Header */}
      <div className="p-5 border-b border-slate-800 flex items-center space-x-3">
        <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-500/20">
          <IconSettings className="text-white w-5 h-5" />
        </div>
        <h1 className="text-lg font-bold text-white tracking-tight">Dataset Builder</h1>
      </div>

      {/* Scrollable Config Area */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 scrollbar-thin scrollbar-thumb-slate-800">
        
        {/* Progress Section */}
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <div className="flex justify-between items-end mb-2">
            <Label className="!mb-0">Progreso</Label>
            <span className="text-xs font-mono text-blue-400">
              {currentCount} / {config.targetCount}
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
            <div 
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Global Settings */}
        <div className="space-y-4">
          <div>
            <Label>Objetivo de Ejemplos</Label>
            <Input 
              type="number" 
              value={config.targetCount} 
              onChange={(e) => handleChange('targetCount', parseInt(e.target.value) || 0)}
              min={1}
            />
          </div>

          <div>
            <Label>Nombre del Archivo</Label>
            <div className="relative">
              <Input 
                type="text" 
                value={config.filename} 
                onChange={(e) => handleChange('filename', e.target.value)}
                className="pr-16"
              />
              <span className="absolute right-3 top-2.5 text-slate-500 text-sm pointer-events-none">
                .jsonl
              </span>
            </div>
          </div>
        </div>

        <hr className="border-slate-800" />

        {/* Format Configuration */}
        <div className="space-y-4">
          <div>
            <Label>Formato del Dataset</Label>
            <Select 
              value={config.format} 
              onChange={(e) => handleChange('format', e.target.value as FormatType)}
            >
              <option value="sharegpt">ShareGPT</option>
              <option value="openai">OpenAI (Estándar)</option>
            </Select>
            <p className="mt-2 text-xs text-slate-500 leading-relaxed">
              {config.format === 'sharegpt' 
                ? 'Estructura: { from, value }. Usa "human" y "gpt".' 
                : 'Estructura: { role, content }. Usa "user" y "assistant".'
              }
            </p>
          </div>

          <div className="space-y-3">
             <Toggle 
               label="¿Usar Prompt de Sistema Fijo?" 
               checked={config.useFixedSystemPrompt} 
               onChange={(val) => handleChange('useFixedSystemPrompt', val)}
             />
             
             {config.useFixedSystemPrompt && (
               <div className="animate-fadeIn">
                 <Label>Prompt del Sistema Global</Label>
                 <Textarea 
                   value={config.fixedSystemPrompt}
                   onChange={(e) => handleChange('fixedSystemPrompt', e.target.value)}
                   rows={6}
                   placeholder="ej. Eres un asistente útil especializado en programación Python..."
                   className="text-xs font-mono leading-relaxed"
                 />
               </div>
             )}
          </div>
        </div>

        <div className="space-y-2 p-4 bg-slate-900/40 border border-slate-800 rounded-xl">
          <div className="flex items-center justify-between">
            <Label className="!mb-0">Archivo de escritura</Label>
            <Button variant="secondary" size="sm" onClick={onPickFile}>
              Elegir archivo
            </Button>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Cada vez que añadas un ejemplo en modo Manual se anexará como línea JSONL en el archivo seleccionado.
          </p>
          <p className="text-xs text-blue-300 font-mono">{fileStatus}</p>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="p-5 border-t border-slate-800 bg-slate-900/30">
        <Button 
          variant="primary" 
          className="w-full flex items-center justify-center space-x-2"
          onClick={onDownload}
          disabled={currentCount === 0}
        >
          <IconDownload className="w-4 h-4" />
          <span>Exportar JSONL</span>
        </Button>
      </div>
    </aside>
  );
};